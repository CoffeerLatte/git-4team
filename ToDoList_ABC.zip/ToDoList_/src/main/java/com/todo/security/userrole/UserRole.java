package com.todo.security.userrole;

public enum UserRole {

		USER, ADMIN;
}
